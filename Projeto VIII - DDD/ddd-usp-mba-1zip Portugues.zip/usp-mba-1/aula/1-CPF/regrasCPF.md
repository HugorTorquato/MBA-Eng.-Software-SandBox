# Regras para um CPF Válido

## Estrutura do CPF

O CPF é um número formado por 11 dígitos decimais com a seguinte configuração: ABC.DEF.GHI-JK

**Exemplo de CPF**: `123.456.789-09`.
